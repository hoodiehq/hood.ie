
 /$$                                 /$$ /$$
| $$                                | $$|__/
| $$$$$$$   /$$$$$$   /$$$$$$   /$$$$$$$ /$$  /$$$$$$
| $$__  $$ /$$__  $$ /$$__  $$ /$$__  $$| $$ /$$__  $$
| $$  \ $$| $$  \ $$| $$  \ $$| $$  | $$| $$| $$$$$$$$
| $$  | $$| $$  | $$| $$  | $$| $$  | $$| $$| $$_____/
| $$  | $$|  $$$$$$/|  $$$$$$/|  $$$$$$$| $$|  $$$$$$$
|__/  |__/ \______/  \______/  \_______/|__/ \_______/

Welcome to the Hoodie Presentations! 

A few things we’d like you to know …

# The presentation
It’s around 30mins long and you can adjust it to your needs.

# Font
This presentation looks best with Lora Font which you can download here: https://www.google.com/fonts#UsePlace:use/Collection:Lora (ideally, download all styles & install them before opening the presentation in Keynote. Then it all should work automatically).

Enjoy!

<3
The Hoodies